//
//  CourseViewController.swift
//  currency Today
//
//  Created by Student on 02.07.25.
//

import UIKit
class CoursOption{
    var name: String
    var currency: String
    var course:String
    var backgroundColor:UIColor
    init(name: String, currency: String, course: String, backgroundColor: UIColor) {
        self.name = name
        self.currency = currency
        self.course = course
        self.backgroundColor = backgroundColor
    }
}
class CourseViewController: UIViewController {
    
    @IBOutlet weak var date: UINavigationBar!
    
    @IBOutlet weak var tableView: UITableView!
    var models = [CoursOption]()
   
    
    
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(CoursTableViewCell.self, forCellReuseIdentifier: CoursTableViewCell.identifier)
        currentData()
        
        // Do any additional setup after loading the view.
    }
    func currentData(){
        var now = Date()
        var nowComponents = DateComponents()
        let calendar = Calendar.current
        nowComponents.year = Calendar.current.component(.year, from: now)
        nowComponents.month = Calendar.current.component(.month, from:now)
        nowComponents.day = Calendar.current.component(.day, from:now)
        nowComponents.timeZone = NSTimeZone.local
        now = calendar.date(from:nowComponents)!
        date.topItem?.title = "\(nowComponents.day!).\(nowComponents.month!).\(nowComponents.year!)"
    }
    
    @IBAction func SettingButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "SettingstViewController") as? SettingsViewController
        vc?.modalTransitionStyle = .crossDissolve
        vc?.modalPresentationStyle = .overFullScreen
        self.present(vc!, animated: true)
        
        
    }
    
    
    func configure(){
        
        models.append(contentsOf: [
            CoursOption(name: "AMD", currency:"Armenia", course: "1", backgroundColor: .systemTeal),
            CoursOption(name: "RUB", currency:"Russian", course: "1", backgroundColor: .systemTeal),
            CoursOption(name: "USD", currency:"USA", course: "1", backgroundColor: .systemTeal),
        ])
      
      
    }
    
    
    @IBAction func ConvertButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ConvertViewController") as? ConvertViewController
        vc?.modalTransitionStyle = .flipHorizontal
        vc?.modalPresentationStyle = .overCurrentContext
        self.present(vc!, animated: true)
    }    /*
          // MARK: - Navigation
          
          // In a storyboard-based application, you will often want to do a little preparation before navigation
          override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          // Get the new view controller using segue.destination.
          // Pass the selected object to the new view controller.
          }
          */
}
    extension CourseViewController:
        UITableViewDelegate,
        UITableViewDataSource{
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return models.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let model = models[indexPath.row]
            guard let cell = tableView.dequeueReusableCell(withIdentifier:CoursTableViewCell.identifier , for: indexPath) as? CoursTableViewCell
            else{
                return UITableViewCell()
            }
            //        cell.configure(with: model)
            return cell
        }
            func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                return 70
            }
            
            func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                self.tableView.deselectRow(at: indexPath, animated: true)
            }
        }
    
